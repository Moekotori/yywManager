# 音游窝（yinyouwo） AstrBot 插件

基于 [AstrBot](https://github.com/aobama-astr/AstrBot) 的“音游窝”管理插件：计时扣费、余额、预约与审批、营业/闭店一键切换。

## ✨ 功能特性
- 出勤/退勤：30 分钟为计费单位（不足进一），默认 ¥12/小时，2 分钟内免单。
- 余额/排行榜：简单账户系统与 Top10 榜单。
- 折扣：支持为指定 QQ 设置个人折扣（如 50%/0.5）。
- 预约：用户提交申请；管理员 `confirm [QQ]` 审批后生效，自动 @ 提醒。
- 预约人数：每日预约上限（仅统计“已通过”人数）。
- 营业/闭店：闭店时自动拦截大部分用户命令（管理员与帮助不受影响）。
- SQLite 永久化：自动迁移、线程/协程安全（asyncio.Lock）。

## 📦 安装与使用
1. 将本仓库放入 AstrBot 的插件目录；或把 `main.py` 放至任意插件路径。
2. 启动 AstrBot，查看日志中是否出现 `音游窝系统插件 2.4.0`。
3. 在群内或私聊尝试以下指令：

**用户指令**
```
出勤
退勤
查询信息
余额
出勤列表
排行榜
预约
预约列表
取消预约
```

**管理员指令**
```
营业
闭店
预约人数 <数字>
confirm [QQ]
充值 <QQ> <金额>
扣款 <QQ> <金额>
折扣 <QQ> <折扣率>   # 50% 或 0.5
```

> OneBot CQ 适配：通过 `[CQ:at,qq=123456]` 艾特被批准的预约者。无法识别平台时退化为 `@QQ` 文本。

## ⚙️ 配置
编辑 `main.py` 顶部：
- `HOURLY_FEE`：小时单价
- `GRACE_PERIOD_SECONDS`：免单时长
- `ADMIN_IDS`：管理员 QQ 白名单

数据文件位于：`data/yinyouwo/user_data.db`。

## 🗄️ 数据库结构（自动迁移）
- `user_data(qq, balance, joined_at, total_time, today_date, today_consumption, discount)`
- `reservations(qq, date, time, status, requested_at)`
- `reservation_limit(max_limit)`
- `store_state(is_open)`

## 🧪 开发
```bash
python -m pip install -r requirements.txt
# 代码风格检查
ruff check .
# 格式化
ruff format .
# 运行最小单元测试
pytest -q
```

## 📝 许可证
本项目默认使用 MIT 许可证（见 [LICENSE](./LICENSE)）。

