# Contributing

1. Fork & create a feature branch.
2. Use `ruff check .` and `ruff format .` before committing.
3. Add tests for new behavior when applicable.
4. Open a Pull Request and describe changes clearly.
