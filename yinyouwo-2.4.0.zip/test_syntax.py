def test_importable():
    # Ensure plugin file at least parses as Python code.
    src = open('main.py','r', encoding='utf-8').read()
    compile(src, 'main.py', 'exec')
