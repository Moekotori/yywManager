
from astrbot.api.event import filter, AstrMessageEvent, MessageEventResult
from astrbot.api.star import Star, register
from astrbot.api import logger
from pathlib import Path
import sqlite3
import asyncio
import time
import math
from datetime import date
from typing import Any, Dict, Optional

PLUGIN_NAME = "yinyouwo"
VERSION = "2.4.0"  # + 营业/闭店 + 预约审批(confirm) + 迁移 + 文档化
AUTHOR = "akkariin"

# --- 配置项 ---
HOURLY_FEE = 12.0  # 每小时 12 元
GRACE_PERIOD_SECONDS = 120  # 2分钟内的退勤为免费

ADMIN_IDS = {"2331103944", "87654321"}

FEE_PER_30_MINS = HOURLY_FEE / 2  # 每 30 分钟的费用 = 6.0

# 数据目录和 SQLite 文件
try:
    DATA_DIR = Path(__file__).parent / "data" / PLUGIN_NAME
except NameError:
    DATA_DIR = Path.cwd() / "data" / PLUGIN_NAME
DB_FILE = DATA_DIR / "user_data.db"

# 使用 asyncio 的锁，保护数据库并发访问
_LOCK = asyncio.Lock()


@register(PLUGIN_NAME, AUTHOR, "音游窝系统插件 " + VERSION, VERSION)
class YinyouwoPlugin(Star):
    def __init__(self, context):
        super().__init__(context)
        self.initialized_successfully = False
        try:
            logger.info(f"[{PLUGIN_NAME}] 正在初始化，数据目录: {DATA_DIR}")
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            self.conn = sqlite3.connect(DB_FILE, check_same_thread=False, timeout=10)
            self._init_db()
            self.initialized_successfully = True
        except Exception as e:
            logger.error(f"[{PLUGIN_NAME}] 插件初始化失败！请检查目录权限或路径配置。")
            logger.exception(e)

    async def initialize(self):
        if self.initialized_successfully:
            logger.info(f"🎵 [{PLUGIN_NAME}] 插件已成功初始化，版本 {VERSION}")
        else:
            logger.error(f"[{PLUGIN_NAME}] 插件未成功初始化，将无法正常工作。")

    def _check_init(self, evt: AstrMessageEvent) -> Optional[MessageEventResult]:
        if not self.initialized_successfully:
            return evt.plain_result("❌ 插件服务异常，请联系管理员。")
        return None

    def _init_db(self):
        """创建/更新表：user_data / reservations(+status,requested_at) / reservation_limit / store_state"""
        with self.conn:
            # 用户主表
            self.conn.execute("""
            CREATE TABLE IF NOT EXISTS user_data (
                qq TEXT PRIMARY KEY,
                balance REAL NOT NULL DEFAULT 0,
                joined_at REAL,
                total_time REAL NOT NULL DEFAULT 0,
                today_date TEXT,
                today_consumption REAL NOT NULL DEFAULT 0,
                discount REAL NOT NULL DEFAULT 1.0
            )""")
            # 尝试新增 discount（兼容旧表）
            try:
                self.conn.execute("ALTER TABLE user_data ADD COLUMN discount REAL NOT NULL DEFAULT 1.0")
                logger.info(f"[{PLUGIN_NAME}] 数据库已更新，增加了 'discount' 字段。")
            except sqlite3.OperationalError:
                pass

            # 预约表（老结构：qq, date, time） -> 加 status, requested_at
            self.conn.execute("""
            CREATE TABLE IF NOT EXISTS reservations (
                qq TEXT,
                date TEXT,
                time TEXT
            )""")
            # 迁移：status
            try:
                self.conn.execute("ALTER TABLE reservations ADD COLUMN status TEXT NOT NULL DEFAULT 'approved'")
            except sqlite3.OperationalError:
                pass
            # 迁移：requested_at
            try:
                self.conn.execute("ALTER TABLE reservations ADD COLUMN requested_at REAL")
            except sqlite3.OperationalError:
                pass

            # 预约人数上限
            self.conn.execute("CREATE TABLE IF NOT EXISTS reservation_limit (max_limit INTEGER)")
            # 兼容旧 limit 列名
            try:
                cur = self.conn.cursor()
                cur.execute("PRAGMA table_info(reservation_limit)")
                columns = [row[1] for row in cur.fetchall()]
                if 'limit' in columns and 'max_limit' not in columns:
                    self.conn.execute("ALTER TABLE reservation_limit RENAME COLUMN limit TO max_limit")
                elif 'limit' in columns and 'max_limit' in columns:
                    cur.execute("SELECT max_limit FROM reservation_limit LIMIT 1")
                    existing_value = cur.fetchone()
                    value = existing_value[0] if existing_value else 9999
                    self.conn.execute("DROP TABLE reservation_limit")
                    self.conn.execute("CREATE TABLE reservation_limit (max_limit INTEGER)")
                    self.conn.execute("INSERT INTO reservation_limit(max_limit) VALUES(?)", (value,))
            except sqlite3.OperationalError as e:
                logger.warning(f"[{PLUGIN_NAME}] 预约上限迁移警告: {e}")

            # 初始化一条记录
            cur = self.conn.cursor()
            cur.execute("SELECT COUNT(*) FROM reservation_limit")
            if cur.fetchone()[0] == 0:
                self.conn.execute("INSERT INTO reservation_limit(max_limit) VALUES(?)", (9999,))

            # 新增：营业状态表（1=营业，0=闭店）
            self.conn.execute("""
            CREATE TABLE IF NOT EXISTS store_state (
                is_open INTEGER NOT NULL
            )""")
            cur.execute("SELECT COUNT(*) FROM store_state")
            if cur.fetchone()[0] == 0:
                self.conn.execute("INSERT INTO store_state(is_open) VALUES(1)")  # 默认营业

    def _today(self) -> str:
        return date.today().isoformat()

    def _get_uid(self, evt) -> str:
        # 1) Aiocqhttp: get_sender_id()
        try:
            if hasattr(evt, "get_sender_id"):
                val = evt.get_sender_id()
                if val:
                    return str(val)
        except Exception:
            pass
        # 2) 通用 API: get_user_id()
        try:
            if hasattr(evt, "get_user_id"):
                val = evt.get_user_id()
                if val:
                    return str(val)
        except Exception:
            pass
        # 3) 直接属性: user_id
        if hasattr(evt, "user_id"):
            val = getattr(evt, "user_id")
            if val:
                return str(val)
        # 4) evt.sender.user_id / evt.sender.id
        sender = getattr(evt, "sender", None)
        if sender:
            if hasattr(sender, "user_id") and getattr(sender, "user_id"):
                return str(sender.user_id)
            if hasattr(sender, "id") and getattr(sender, "id"):
                return str(sender.id)
        # 5) evt.message.sender.user_id / id
        msg = getattr(evt, "message", None)
        if msg and hasattr(msg, "sender"):
            snd = msg.sender
            if hasattr(snd, "user_id") and getattr(snd, "user_id"):
                return str(snd.user_id)
            if hasattr(snd, "id") and getattr(snd, "id"):
                return str(snd.id)
        # 6) raw_event 字典查找
        raw = getattr(evt, "raw_event", {}) or {}
        if isinstance(raw, dict):
            # top-level
            for key in ("user_id", "userId", "sender_id"):
                if raw.get(key):
                    return str(raw.get(key))
            # nested sender
            sender2 = raw.get("sender") or raw.get("user") or {}
            if isinstance(sender2, dict):
                for key in ("user_id", "userId", "id"):
                    if sender2.get(key):
                        return str(sender2.get(key))
            # nested message.sender
            msg2 = raw.get("message", {})
            if isinstance(msg2, dict):
                snd2 = msg2.get("sender") or {}
                if isinstance(snd2, dict):
                    for key in ("user_id", "userId", "id"):
                        if snd2.get(key):
                            return str(snd2.get(key))
        logger.error(f"[{PLUGIN_NAME}] _get_uid 失败，evt 属性有: {dir(evt)}; raw_event={raw}")
        return ""

    def _format_time(self, seconds: float) -> str:
        if seconds < 0:
            seconds = 0
        h, rem = divmod(int(seconds), 3600)
        m, s = divmod(rem, 60)
        parts = []
        if h:
            parts.append(f"{h}小时")
        if m:
            parts.append(f"{m}分钟")
        parts.append(f"{s}秒")
        return "".join(parts) if parts else "0秒"

    # --- 新增：营业状态 / 权限 / 提醒 ---
    def _is_admin(self, qq: str) -> bool:
        return qq in ADMIN_IDS

    def _is_open(self) -> bool:
        cur = self.conn.cursor()
        cur.execute("SELECT is_open FROM store_state LIMIT 1")
        row = cur.fetchone()
        return bool(row[0]) if row else True

    def _mention(self, qq: str) -> str:
        """优先兼容 OneBot CQ 艾特；无法识别则退化为 @qq 文本。"""
        try:
            int(qq)
            return f"[CQ:at,qq={qq}]"
        except ValueError:
            return f"@{qq}"

    def _guard_open(self, evt: AstrMessageEvent) -> Optional[MessageEventResult]:
        """闭店拦截（管理员放行；帮助类放行）。"""
        qq = self._get_uid(evt)
        if self._is_admin(qq):
            return None
        if not self._is_open():
            return evt.plain_result("🏁 已闭店，今日暂停服务。")
        return None

    # --- 用户数据 ---
    async def _get_user(self, qq: str) -> Optional[Dict[str, Any]]:
        async with _LOCK:
            with self.conn as conn:
                cur = conn.cursor()
                cur.execute("SELECT * FROM user_data WHERE qq=?", (qq,))
                row = cur.fetchone()

                user = None
                if row:
                    cols = [c[0] for c in cur.description]
                    user = dict(zip(cols, row))
                else:
                    today = self._today()
                    conn.execute(
                        "INSERT INTO user_data(qq, today_date, discount) VALUES(?,?,?)",
                        (qq, today, 1.0)
                    )
                    user = {
                        "qq": qq, "balance": 0.0, "joined_at": None,
                        "total_time": 0.0, "today_date": today, "today_consumption": 0.0,
                        "discount": 1.0
                    }

                today = self._today()
                if user and user["today_date"] != today:
                    user["today_date"] = today
                    user["today_consumption"] = 0.0
                    conn.execute(
                        "UPDATE user_data SET today_date=?, today_consumption=? WHERE qq=?",
                        (today, 0.0, qq)
                    )
                return user

    async def _update_user(self, qq: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        async with _LOCK:
            with self.conn as conn:
                cur = conn.cursor()
                cur.execute("SELECT * FROM user_data WHERE qq=?", (qq,))
                row = cur.fetchone()
                if not row:
                    raise ValueError(f"尝试更新一个不存在的用户: {qq}")

                cols = [c[0] for c in cur.description]
                user = dict(zip(cols, row))
                user.update(updates)

                conn.execute("""
                UPDATE user_data SET
                  balance=?, joined_at=?, total_time=?,
                  today_date=?, today_consumption=?, discount=?
                WHERE qq=?
                """, (
                    user["balance"], user["joined_at"], user["total_time"],
                    user["today_date"], user["today_consumption"], user["discount"],
                    user["qq"]
                ))
                return user

    # --- 用户指令（闭店期间受限） ---
    @filter.command("出勤", only_to_me=False)
    async def cmd_attend(self, evt: AstrMessageEvent) -> MessageEventResult:
        if init_error := self._check_init(evt): return init_error
        if blocked := self._guard_open(evt): return blocked
        qq = self._get_uid(evt)
        if not qq: return evt.plain_result("❌ 无法识别用户QQ，操作失败")

        user = await self._get_user(qq)
        if user["joined_at"] is not None: return evt.plain_result("❌ 你已出勤，无需重复操作")

        await self._update_user(qq, {"joined_at": time.time()})
        return evt.plain_result(f"✅ 出勤成功，余额 {user['balance']:.2f} 元")

    @filter.command("退勤", only_to_me=False)
    async def cmd_leave(self, evt: AstrMessageEvent) -> MessageEventResult:
        if init_error := self._check_init(evt): return init_error
        if blocked := self._guard_open(evt): return blocked
        qq = self._get_uid(evt)
        if not qq: return evt.plain_result("❌ 无法识别用户QQ，操作失败")

        user = await self._get_user(qq)
        if user["joined_at"] is None: return evt.plain_result("❌ 你尚未出勤，请先发送“出勤”")

        now = time.time()
        duration = now - user["joined_at"]

        if duration <= GRACE_PERIOD_SECONDS:
            await self._update_user(qq, {"joined_at": None})
            return evt.plain_result(f"✅ 退勤成功，本次出勤时长小于2分钟，免于计费。")

        billing_units = math.ceil(duration / 1800)
        base_fee = billing_units * FEE_PER_30_MINS
        final_fee = base_fee * user.get("discount", 1.0)

        if user["balance"] < final_fee:
            return evt.plain_result(
                f"❌ 余额不足，无法退勤。\n"
                f"本次需支付 {final_fee:.2f} 元，当前余额 {user['balance']:.2f} 元。"
            )

        updated_user = await self._update_user(qq, {
            "balance": user["balance"] - final_fee,
            "today_consumption": user["today_consumption"] + final_fee,
            "total_time": user["total_time"] + duration,
            "joined_at": None
        })

        return evt.plain_result(
            f"✅ 退勤成功，在线 {self._format_time(duration)}，"
            f"扣费 {final_fee:.2f} 元，今日消费 {updated_user['today_consumption']:.2f} 元，"
            f"余额 {updated_user['balance']:.2f} 元"
        )

    @filter.command("查询信息", only_to_me=False)
    async def cmd_info(self, evt: AstrMessageEvent) -> MessageEventResult:
        if init_error := self._check_init(evt): return init_error
        if blocked := self._guard_open(evt): return blocked
        qq = self._get_uid(evt)
        if not qq: return evt.plain_result("❌ 无法识别用户QQ，操作失败")

        user = await self._get_user(qq)
        status = "🎮 出勤中" if user["joined_at"] else "🏁 已退勤"
        discount_rate = user.get("discount", 1.0)
        discount_str = f" (当前享受 {discount_rate:.0%} 折扣)" if discount_rate < 1.0 else ""

        msg = [
            f"👤 QQ：{qq}",
            f"📋 状态：{status}",
            f"💰 余额：{user['balance']:.2f} 元{discount_str}",
            f"🕑 今日消费：{user['today_consumption']:.2f} 元",
            f"⏳ 总时长：{self._format_time(user['total_time'])}"
        ]
        return evt.plain_result("\n".join(msg))

    @filter.command("出勤列表", only_to_me=False)
    async def cmd_list(self, evt: AstrMessageEvent) -> MessageEventResult:
        if init_error := self._check_init(evt): return init_error
        if blocked := self._guard_open(evt): return blocked
        now = time.time()
        async with _LOCK:
            with self.conn as conn:
                cur = conn.execute(
                    "SELECT qq, joined_at FROM user_data WHERE joined_at IS NOT NULL ORDER BY joined_at ASC"
                )
                lines = [
                    f"• {row[0]}：{self._format_time(now - row[1])}"
                    for row in cur.fetchall()
                ]

        if not lines:
            return evt.plain_result("📭 目前没有任何人出勤")
        return evt.plain_result("📋 当前出勤列表：\n" + "\n".join(lines))

    @filter.command("余额", only_to_me=False)
    async def cmd_balance(self, evt: AstrMessageEvent) -> MessageEventResult:
        if init_error := self._check_init(evt): return init_error
        if blocked := self._guard_open(evt): return blocked
        qq = self._get_uid(evt)
        if not qq:
            return evt.plain_result("❌ 无法识别用户QQ，操作失败")
        user = await self._get_user(qq)
        return evt.plain_result(f"💰 QQ {qq} 当前余额：{user['balance']:.2f} 元")

    @filter.command("排行榜", only_to_me=False)
    async def cmd_rank(self, evt: AstrMessageEvent) -> MessageEventResult:
        if init_error := self._check_init(evt): return init_error
        if blocked := self._guard_open(evt): return blocked
        async with _LOCK:
            with self.conn as conn:
                cur = conn.execute(
                    "SELECT qq, balance FROM user_data ORDER BY balance DESC LIMIT 10"
                )
                lines = [f"🏅 {i + 1}. {row[0]}：{row[1]:.2f} 元" for i, row in enumerate(cur.fetchall())]

        if not lines:
            return evt.plain_result("🏆 排行榜暂无数据")
        return evt.plain_result("🏆 余额排行榜：\n" + "\n".join(lines))

    # --- 预约（新增审批流程） ---
    @filter.command("预约", only_to_me=False)
    async def cmd_reserve(self, evt: AstrMessageEvent) -> MessageEventResult:
        init_err = self._check_init(evt)
        if init_err:
            return init_err
        if blocked := self._guard_open(evt):
            return blocked

        qq = self._get_uid(evt)
        if not qq:
            return evt.plain_result("❌ 无法识别用户QQ，预约失败")

        today = self._today()
        with self.conn as conn:
            cur = conn.cursor()
            # 限额核对：只统计已批准的
            cur.execute("SELECT max_limit FROM reservation_limit")
            limit = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM reservations WHERE date=? AND status='approved'", (today,))
            approved_count = cur.fetchone()[0]

            # 是否已有待审/已批记录
            cur.execute("SELECT status FROM reservations WHERE qq=? AND date=? ORDER BY requested_at DESC LIMIT 1",
                        (qq, today))
            last = cur.fetchone()
            if last:
                if last[0] == 'pending':
                    return evt.plain_result("⌛ 你已有预约申请，等待管理员同意预约申请…")
                else:
                    return evt.plain_result("✅ 你今天已预约成功，无需重复申请")

            # 尚未达上限则允许申请进入待审
            if approved_count >= limit:
                return evt.plain_result(f"❌ 今日预约名额已满（上限 {limit} 人）")

            conn.execute(
                "INSERT INTO reservations(qq, date, time, status, requested_at) VALUES(?,?,?,?,?)",
                (qq, today, "", "pending", time.time())
            )
        return evt.plain_result("📝 已提交预约申请，等待管理员同意预约申请…")

    @filter.command("预约列表", only_to_me=False)
    async def cmd_reserve_list(self, evt: AstrMessageEvent) -> MessageEventResult:
        init_err = self._check_init(evt)
        if init_err:
            return init_err
        if blocked := self._guard_open(evt):
            return blocked

        today = self._today()
        with self.conn as conn:
            cur = conn.cursor()
            cur.execute("SELECT qq, time, status FROM reservations WHERE date=? ORDER BY requested_at ASC", (today,))
            rows = cur.fetchall()
        if not rows:
            return evt.plain_result("今日暂无预约")
        def tag(s: str) -> str:
            return {"pending":"[待审]","approved":"[已通过]"}.get(s, f"[{s}]")
        lines = [f"{i+1}. QQ:{qq} {t or ''} {tag(st)}" for i, (qq, t, st) in enumerate(rows)]
        return evt.plain_result("今日预约：\n" + "\n".join(lines))

    @filter.command("取消预约", only_to_me=False)
    async def cmd_cancel_reserve(self, evt: AstrMessageEvent) -> MessageEventResult:
        init_err = self._check_init(evt)
        if init_err:
            return init_err
        if blocked := self._guard_open(evt):
            return blocked

        qq = self._get_uid(evt)
        if not qq:
            return evt.plain_result("❌ 无法识别用户QQ，操作失败")
        today = self._today()
        with self.conn as conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM reservations WHERE qq=? AND date=?", (qq, today))
            if cur.rowcount == 0:
                return evt.plain_result("❌ 你今天未预约，无需取消")
        return evt.plain_result("✅ 预约取消成功")

    @filter.command("预约人数", only_to_me=False)
    async def cmd_reserve_limit(self, evt: AstrMessageEvent) -> MessageEventResult:
        init_err = self._check_init(evt)
        if init_err:
            return init_err

        op_qq = self._get_uid(evt)
        if op_qq not in ADMIN_IDS:
            return evt.plain_result("❌ 权限不足")

        msg = (getattr(evt, "message_str", "") or "").strip()
        tokens = msg.split()

        arg = None
        if len(tokens) >= 2:
            arg = tokens[1]
        elif len(tokens) == 1:
            if tokens[0].lstrip("+-").isdigit():
                arg = tokens[0]

        if not arg:
            with self.conn as conn:
                cur = conn.cursor()
                cur.execute("SELECT max_limit FROM reservation_limit")
                limit = cur.fetchone()[0]
            return evt.plain_result(f"当前每日预约上限：{limit}人")

        try:
            new_limit = int(arg)
            if new_limit < 0:
                return evt.plain_result("❌ 预约上限必须是非负整数")
        except Exception:
            return evt.plain_result("❌ 格式错误。用法：预约人数 <数字>，例如：预约人数 6")

        with self.conn as conn:
            conn.execute("UPDATE reservation_limit SET max_limit=?", (new_limit,))
        return evt.plain_result(f"✅ 已将每日预约上限设置为：{new_limit}人")

    # --- 管理员审批：confirm [QQ] ---
    @filter.command("confirm", aliases={"同意预约","同意"}, only_to_me=False)
    async def cmd_confirm(self, evt: AstrMessageEvent) -> MessageEventResult:
        if init_error := self._check_init(evt): return init_error
        op_qq = self._get_uid(evt)
        if op_qq not in ADMIN_IDS:
            return evt.plain_result("❌ 权限不足")

        msg = (getattr(evt, "message_str", "") or "").strip()
        parts = msg.split()
        target_qq = None
        if len(parts) >= 2:
            target_qq = parts[1].strip()

        today = self._today()
        with self.conn as conn:
            cur = conn.cursor()
            # 限额仅对已通过计数
            cur.execute("SELECT max_limit FROM reservation_limit")
            limit = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM reservations WHERE date=? AND status='approved'", (today,))
            approved_count = cur.fetchone()[0]
            if approved_count >= limit:
                return evt.plain_result(f"❌ 今日已达预约上限（{limit}人），无法再通过申请")

            # 选择一个待审记录：指定 qq 优先，否则取最早
            if target_qq:
                cur.execute("""
                    SELECT rowid, qq FROM reservations
                    WHERE date=? AND status='pending' AND qq=?
                    ORDER BY requested_at ASC LIMIT 1
                """, (today, target_qq))
            else:
                cur.execute("""
                    SELECT rowid, qq FROM reservations
                    WHERE date=? AND status='pending'
                    ORDER BY requested_at ASC LIMIT 1
                """, (today,))
            row = cur.fetchone()
            if not row:
                return evt.plain_result("ℹ️ 当前没有待审的预约申请")
            rid, qq = row

            # 通过
            conn.execute("UPDATE reservations SET status='approved' WHERE rowid=?", (rid,))

        # 提示并艾特对方
        return evt.plain_result(f"✅ 已通过预约申请：{self._mention(qq)} 预约成功！")

    # --- 管理员基础财务指令 ---
    async def _admin_op(self, evt: AstrMessageEvent, op_type: str) -> MessageEventResult:
        op_qq = self._get_uid(evt)
        if op_qq not in ADMIN_IDS: return evt.plain_result("❌ 权限不足")

        parts = evt.message_str.split()
        if len(parts) != 3: return evt.plain_result(f"❌ 格式错误。用法：{op_type} <QQ号> <金额>")

        target_qq, amount_str = parts[1], parts[2]

        if not target_qq.isdigit():
            return evt.plain_result("❌ QQ号格式错误，必须为纯数字。")
        try:
            amount = float(amount_str)
            if amount <= 0:
                raise ValueError("金额必须为正数")
        except ValueError:
            return evt.plain_result("❌ 金额格式错误，必须是大于0的数字。")

        user = await self._get_user(target_qq)
        new_balance = user["balance"]

        if op_type == "充值":
            new_balance += amount
            action_text = "充值"
        else:  # 扣款
            if user["balance"] < amount:
                return evt.plain_result(f"❌ 目标余额 {user['balance']:.2f} 元，不足以扣除 {amount:.2f} 元")
            new_balance -= amount
            action_text = "扣款"

        updated_user = await self._update_user(target_qq, {"balance": new_balance})
        return evt.plain_result(
            f"✅ 已为 QQ {target_qq} {action_text} {amount:.2f} 元，"
            f"其新余额为 {updated_user['balance']:.2f} 元"
        )

    @filter.command("充值", only_to_me=False)
    async def cmd_charge(self, evt: AstrMessageEvent) -> MessageEventResult:
        if init_error := self._check_init(evt): return init_error
        return await self._admin_op(evt, "充值")

    @filter.command("扣款", only_to_me=False)
    async def cmd_deduct(self, evt: AstrMessageEvent) -> MessageEventResult:
        if init_error := self._check_init(evt): return init_error
        return await self._admin_op(evt, "扣款")

    @filter.command("折扣", only_to_me=False)
    async def cmd_discount(self, evt: AstrMessageEvent) -> MessageEventResult:
        if init_error := self._check_init(evt): return init_error
        op_qq = self._get_uid(evt)
        if op_qq not in ADMIN_IDS: return evt.plain_result("❌ 权限不足")

        parts = evt.message_str.split()
        if len(parts) != 3: return evt.plain_result("❌ 格式错误。用法：折扣 <QQ号> <折扣率>")

        target_qq, discount_str = parts[1], parts[2]

        if not target_qq.isdigit():
            return evt.plain_result("❌ QQ号格式错误，必须为纯数字。")
        try:
            if discount_str.endswith('%'):
                rate = float(discount_str.strip('%')) / 100.0
            else:
                rate = float(discount_str)

            if not (0.0 < rate <= 1.0):
                raise ValueError("折扣率必须在 (0, 1] 区间内，即 0% 到 100%")
        except (ValueError, TypeError):
            return evt.plain_result("❌ 折扣率格式错误。请输入如 50% 或 0.5 的值。")

        await self._get_user(target_qq)
        await self._update_user(target_qq, {"discount": rate})

        return evt.plain_result(f"✅ 已为 QQ {target_qq} 设置折扣为 {rate:.0%}")

    # --- 新增：营业/闭店 ---
    @filter.command("营业", only_to_me=False)
    async def cmd_open_store(self, evt: AstrMessageEvent) -> MessageEventResult:
        if init_error := self._check_init(evt): return init_error
        qq = self._get_uid(evt)
        if qq not in ADMIN_IDS:
            return evt.plain_result("❌ 权限不足")
        with self.conn as conn:
            conn.execute("UPDATE store_state SET is_open=1")
        return evt.plain_result("🟢 已切换为『营业』状态，用户功能恢复可用。")

    @filter.command("闭店", only_to_me=False)
    async def cmd_close_store(self, evt: AstrMessageEvent) -> MessageEventResult:
        if init_error := self._check_init(evt): return init_error
        qq = self._get_uid(evt)
        if qq not in ADMIN_IDS:
            return evt.plain_result("❌ 权限不足")
        with self.conn as conn:
            conn.execute("UPDATE store_state SET is_open=0")
        return evt.plain_result("🔴 已切换为『闭店』状态，用户功能已暂停。")

    @filter.command("帮助", aliases={"help"}, only_to_me=False)
    async def cmd_help(self, evt: AstrMessageEvent) -> MessageEventResult:
        if init_error := self._check_init(evt): return init_error
        open_tag = "🟢营业中" if self._is_open() else "🔴已闭店"
        return evt.plain_result(
            f"🎵 rinNet v{VERSION} 🎵  {open_tag}\n\n"
            "【用户指令】\n"
            " • 出勤  (开始计时)\n"
            " • 退勤  (结束计时并结算)\n"
            " • 查询信息  (查看我的状态)\n"
            " • 余额  (查看我的余额)\n"
            " • 出勤列表  (查看所有在线用户)\n"
            " • 排行榜  (查看排行榜)\n"
            " • 预约  (提交预约申请，需管理员同意后生效)\n"
            " • 预约列表  (查看今日预约：待审/已通过)\n"
            " • 取消预约  (取消我的预约)\n\n"
            "【管理员指令】\n"
            " • 营业 / 闭店  (切换营业状态)\n"
            " • 预约人数 <数字>  (设置每日预约上限)\n"
            " • confirm [QQ]  (同意预约申请；可指定 QQ 或省略以通过最早待审)\n"
            " • 充值 <QQ> <金额>\n"
            " • 扣款 <QQ> <金额>\n"
            " • 折扣 <QQ> <折扣率> (例: 50% 或 0.5)\n\n"
            f"计费标准：每30分钟 {FEE_PER_30_MINS:.2f} 元（每小时 {HOURLY_FEE:.2f} 元），不足30分钟按30分钟计。2分钟内退勤免费。"
        )

    async def terminate(self):
        if self.initialized_successfully:
            self.conn.close()
            logger.info(f"🎵 [{PLUGIN_NAME}] 已卸载，SQLite已关闭")
