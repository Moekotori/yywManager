# Security Policy

If you discover a vulnerability, please open a private advisory on GitHub or contact the maintainer.
